 function media(){
     var nota1 = parseFloat(document.getElementById("nota1").value);
     var nota2 = parseFloat(document.getElementById("nota2").value);

     var media = (nota1 + nota2)/2 ;

     if(media >= 7)
       alert("Aluno aprovado com media: "+media);
     else
      alert("Aluno Reprovado!")

    }