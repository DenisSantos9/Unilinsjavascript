var operador   = '';
var val1, val2 = 0;
var separador  = 0;
var maxdigitos = 0;

function leDigitos(num){   
   if(maxdigitos > 12){
      return;
   }
   if(separador >= 0 && num !== '.'){
      document.getElementById("visor1").innerHTML += num;      
   } else if(separador === 0 && num === '.'){
      document.getElementById("visor1").innerHTML += num;
      separador++;
   }
   maxdigitos++;
}

function leOpBasica(op){
   if(document.getElementById("visor1").innerHTML === ''){
      return;
   }
   
   val1 = document.getElementById("visor1").innerHTML;  
   var visor_1 = (document.getElementById("visor1").innerHTML += op);
   document.getElementById("visor2").innerHTML = visor_1;
   document.getElementById("visor1").innerHTML = '';   
   operador = op;
   separador = 0;
   val2 = 0;
   maxdigitos = 0;
}

function percent(){
   val2 = document.getElementById("visor1").innerHTML;   
   val2 = (val2/100) * val1;
   document.getElementById("visor1").innerHTML = val2 + '%';   
}

function resultado(){
   if(val2 === 0){
      val2 = document.getElementById("visor1").innerHTML;
      if(val2 === ''){       
         return;
      }
   } 
   
   console.log(val1 + '   ' + operador + '   ' + val2);
   
   var result = '';
   switch(operador){
      case '÷': result = parseFloat(val1) / parseFloat(val2);
         break;
      case 'x': result = parseFloat(val1) * parseFloat(val2);
         break;
      case '-': result = parseFloat(val1) - parseFloat(val2);
         break;
      case '+': result = parseFloat(val1) + parseFloat(val2);        
         break;
   } 
   
   document.getElementById("visor2").innerHTML = '';  
   val1 = (document.getElementById("visor1").innerHTML = Math.round(result * 10000000) / 10000000); //Testar com 0.6*3=1.8 //Arrendonda até 6 decimais
   separador = 0;
  
}

function limpa(){
   document.getElementById("visor1").innerHTML = '';
   document.getElementById("visor2").innerHTML = '';
   operador = '';
   val1 = val2 = 0;
   separador = 0;
   maxdigitos = 0;
}

function troca(){
   document.getElementById("visor1").innerHTML *= -1;
}