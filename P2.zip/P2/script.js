var alunos = new Array();
function salvar(){
	var aluno = new Object();
	aluno.nome = document.getElementById("nome").value;
	aluno.idade = document.getElementById("idade").value;
	aluno.ra = document.getElementById("ra").value;
	aluno.sexo = document.getElementById("sexo").value;
	aluno.curso = document.getElementById("curso").value;
	alunos.push(aluno);
	document.getElementById("nome").value="";
	document.getElementById("idade").value="";
	document.getElementById("ra").value="";
	document.getElementById("sexo").value="";
	document.getElementById("curso").value="";
}

function tamanho(){
	alert(alunos.length + " aluno(s)");
}

function mostrar(){
	var texto = "";
	for(i = 0; i < alunos.length; i++){
		texto += "Nome: "+alunos[i].nome + 
		" Idade: "+alunos[i].idade+
		" RA: "+alunos[i].ra+
		" Sexo: "+alunos[i].sexo+
		" Curso: "+alunos[i].curso+"\n";
	}
	alert(texto);
}