var aluno = new Array();

function add(){
	var nome = document.getElementById("nome").value; 
	document.getElementById("nome").value="";
	aluno.push(nome);
	alert("Aluno Adicionado")
	console.log("Aluno salvo");
}

function remover(){
	aluno.pop();
	console.log("Aluno removido");
}

function tamanho(){
	console.log("Tamanho: ",aluno.length);
}

function mostrar(){
	var i;
	for(i in aluno){
  		console.log(aluno[i]);
	}	
}