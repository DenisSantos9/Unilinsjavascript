var data = new Date();
function idade(){	
	var diaA = data.getDate();
	var mesA = data.getMonth()+1;
	var anoA = data.getFullYear();
	var dataAtual = document.getElementById("txtidade").value.split("-");
	var diaC = dataAtual[2];
	var mesC = dataAtual[1];
	var anoC = dataAtual[0];
	var idade;
	if((mesA >= mesC) && (diaA >= diaC)){
		idade = anoA - anoC;
	} else {
		idade = anoA - anoC - 1;
	}
	alert(idade+" anos!");
}
function calcularHora(){
	var hora = data.getHours();
	var min = data.getMinutes();
	alert("Hora atual: "+hora+":"+min);
}