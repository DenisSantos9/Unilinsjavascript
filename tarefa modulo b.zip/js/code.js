function calculartemp(){
    var temperatura = document.getElementById("txtNumeros").value;
    if (temperatura != ""){
        if (temperatura > 35){
            alert("Muito quente!");
        } else if (temperatura < 35){
            alert("Muito frio!");
        } else if (temperatura == 35){
            alert("Temperatura Ideal!");
        }
    }
    else {
        alert("Não está fácil para ninguém!");
    }
}   